package vo;

public class prodVO {
	private String prodID;
	private String manufacturer;
	private String PType;
	private String PName;
	private String PImg;
	private String PPlain;
	private String Pspec1;
	private String Pspec2;
	private String Pspec3;
	private String Pspec4;
	private String Pspec5;
	private String Pspec6;
	private String Pspec7;
	private String Pspec8;
	private String Pspec9;
	private String Pspec10;
	private String Pspec11;
	private String Pspec12;
	private String Pspec13;
	
	
	public String getProdID() {
		return prodID;
	}
	public void setProdID(String prodID) {
		this.prodID = prodID;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getPType() {
		return PType;
	}
	public void setPType(String pType) {
		PType = pType;
	}
	public String getPName() {
		return PName;
	}
	public void setPName(String pName) {
		PName = pName;
	}
	public String getPImg() {
		return PImg;
	}
	public void setPImg(String pImg) {
		PImg = pImg;
	}
	public String getPPlain() {
		return PPlain;
	}
	public void setPPlain(String pPlain) {
		PPlain = pPlain;
	}
	public String getPspec1() {
		return Pspec1;
	}
	public void setPspec1(String pspec1) {
		Pspec1 = pspec1;
	}
	public String getPspec2() {
		return Pspec2;
	}
	public void setPspec2(String pspec2) {
		Pspec2 = pspec2;
	}
	public String getPspec3() {
		return Pspec3;
	}
	public void setPspec3(String pspec3) {
		Pspec3 = pspec3;
	}
	public String getPspec4() {
		return Pspec4;
	}
	public void setPspec4(String pspec4) {
		Pspec4 = pspec4;
	}
	public String getPspec5() {
		return Pspec5;
	}
	public void setPspec5(String pspec5) {
		Pspec5 = pspec5;
	}
	public String getPspec6() {
		return Pspec6;
	}
	public void setPspec6(String pspec6) {
		Pspec6 = pspec6;
	}
	public String getPspec7() {
		return Pspec7;
	}
	public void setPspec7(String pspec7) {
		Pspec7 = pspec7;
	}
	public String getPspec8() {
		return Pspec8;
	}
	public void setPspec8(String pspec8) {
		Pspec8 = pspec8;
	}
	public String getPspec9() {
		return Pspec9;
	}
	public void setPspec9(String pspec9) {
		Pspec9 = pspec9;
	}
	public String getPspec10() {
		return Pspec10;
	}
	public void setPspec10(String pspec10) {
		Pspec10 = pspec10;
	}
	public String getPspec11() {
		return Pspec11;
	}
	public void setPspec11(String pspec11) {
		Pspec11 = pspec11;
	}
	public String getPspec12() {
		return Pspec12;
	}
	public void setPspec12(String pspec12) {
		Pspec12 = pspec12;
	}
	public String getPspec13() {
		return Pspec13;
	}
	public void setPspec13(String pspec13) {
		Pspec13 = pspec13;
	}
	
	
}
